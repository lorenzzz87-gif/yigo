/* ============================================================
   SUVOO 面单打印助手（本地运行）
   监视指定文件夹里的面单 PDF（支持一个大 PDF 含多张面单），
   按运单号找到对应页 → 拆出单页 → 静默发送打印机。
   网页扫码时通过 http://127.0.0.1:17777 通知本程序打印。
   Windows 用 SumatraPDF 打印，macOS/Linux 用 lp。
   ============================================================ */
const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { execFile } = require('child_process');

const CFG_PATH = path.join(__dirname, 'config.json');
const CFG = JSON.parse(fs.readFileSync(CFG_PATH, 'utf8'));
const PORT = CFG.port || 17777;

const pdfjs = require('pdfjs-dist/legacy/build/pdf.js');
const { PDFDocument } = require('pdf-lib');

function log(...a) {
  console.log(new Date().toLocaleTimeString('zh-CN', { hour12: false }), ...a);
}

/* ---------- PDF 索引：每页文本缓存（按文件 mtime 失效） ---------- */
const fileCache = new Map(); // file → {mtime, pages:[pageText]}

async function extractPages(fp) {
  const data = new Uint8Array(fs.readFileSync(fp));
  const doc = await pdfjs.getDocument({ data, useSystemFonts: true, isEvalSupported: false }).promise;
  const pages = [];
  for (let i = 1; i <= doc.numPages; i++) {
    const page = await doc.getPage(i);
    const tc = await page.getTextContent();
    pages.push(tc.items.map(it => it.str).join(' '));
  }
  await doc.destroy();
  return pages;
}

async function refreshIndex() {
  let files = [];
  try {
    files = fs.readdirSync(CFG.folder).filter(f => f.toLowerCase().endsWith('.pdf'));
  } catch (e) {
    log('⚠ 无法读取面单文件夹:', CFG.folder, e.message);
    return;
  }
  for (const f of files) {
    const fp = path.join(CFG.folder, f);
    let mt;
    try { mt = fs.statSync(fp).mtimeMs; } catch (e) { continue; }
    const c = fileCache.get(f);
    if (!c || c.mtime !== mt) {
      try {
        const pages = await extractPages(fp);
        fileCache.set(f, { mtime: mt, pages });
        log('已索引:', f, '(' + pages.length + ' 页)');
      } catch (e) {
        log('⚠ 无法解析:', f, e.message);
        fileCache.set(f, { mtime: mt, pages: [] });
      }
    }
  }
  for (const f of [...fileCache.keys()]) {
    if (!files.includes(f)) { fileCache.delete(f); log('已移除:', f); }
  }
}

function stats() {
  let pages = 0;
  for (const c of fileCache.values()) pages += c.pages.length;
  return { files: fileCache.size, pages };
}

// 按运单号找页：文件名含单号优先，其次页内容包含单号（忽略空格/大小写）
function findLabel(no) {
  const needle = String(no).replace(/\s+/g, '').toUpperCase();
  if (!needle) return null;
  for (const f of fileCache.keys()) {
    if (f.replace(/\s+/g, '').toUpperCase().includes(needle)) {
      return { file: f, page: 1, by: 'filename' };
    }
  }
  for (const [f, c] of fileCache) {
    for (let i = 0; i < c.pages.length; i++) {
      if (c.pages[i].replace(/\s+/g, '').toUpperCase().includes(needle)) {
        return { file: f, page: i + 1, by: 'content' };
      }
    }
  }
  return null;
}

/* ---------- 拆页 + 打印 ---------- */
async function printLabel(hit) {
  const src = path.join(CFG.folder, hit.file);
  const doc = await PDFDocument.load(fs.readFileSync(src));
  const out = await PDFDocument.create();
  const [pg] = await out.copyPages(doc, [hit.page - 1]);
  out.addPage(pg);
  const tmp = path.join(os.tmpdir(), 'suvoo_label_' + Date.now() + '.pdf');
  fs.writeFileSync(tmp, await out.save());

  if (CFG.dryRun) {
    log('[dryRun] 跳过实际打印:', hit.file, '第' + hit.page + '页 →', tmp);
    return;
  }
  await new Promise((resolve, reject) => {
    if (process.platform === 'win32') {
      const sumatra = CFG.sumatra || path.join(__dirname, 'SumatraPDF.exe');
      if (!fs.existsSync(sumatra)) {
        return reject(new Error('找不到 SumatraPDF.exe，请放到助手文件夹内（见安装说明）'));
      }
      const args = CFG.printer
        ? ['-print-to', CFG.printer, '-silent', tmp]
        : ['-print-to-default', '-silent', tmp];
      execFile(sumatra, args, err => err ? reject(err) : resolve());
    } else {
      const args = CFG.printer ? ['-d', CFG.printer, tmp] : [tmp];
      execFile('lp', args, err => err ? reject(err) : resolve());
    }
  });
  setTimeout(() => fs.unlink(tmp, () => {}), 60000);
}

/* ---------- HTTP 服务（含 CORS + 私有网络访问头） ---------- */
const HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET,OPTIONS',
  'Access-Control-Allow-Headers': '*',
  'Access-Control-Allow-Private-Network': 'true',
  'Content-Type': 'application/json; charset=utf-8'
};

const server = http.createServer(async (req, res) => {
  const send = (code, obj) => { res.writeHead(code, HEADERS); res.end(JSON.stringify(obj)); };
  if (req.method === 'OPTIONS') { res.writeHead(204, HEADERS); return res.end(); }
  const url = new URL(req.url, 'http://127.0.0.1');
  try {
    if (url.pathname === '/ping') {
      await refreshIndex();
      return send(200, { ok: true, ...stats(), folder: CFG.folder });
    }
    if (url.pathname === '/print') {
      const no = (url.searchParams.get('no') || '').trim();
      if (!no) return send(400, { error: 'missing_no' });
      await refreshIndex();
      const hit = findLabel(no);
      if (!hit) { log('未找到面单:', no); return send(404, { error: 'not_found', no }); }
      await printLabel(hit);
      log('✓ 已打印:', no, '←', hit.file, '第' + hit.page + '页');
      return send(200, { ok: true, no, file: hit.file, page: hit.page });
    }
    send(404, { error: 'unknown_path' });
  } catch (e) {
    log('⚠ 出错:', e.message);
    send(500, { error: String(e.message || e) });
  }
});

server.listen(PORT, '127.0.0.1', async () => {
  log('════════════════════════════════════');
  log(' SUVOO 面单打印助手已启动');
  log(' 端口: http://127.0.0.1:' + PORT);
  log(' 面单文件夹: ' + CFG.folder);
  log(' 打印机: ' + (CFG.printer || '(系统默认)'));
  if (CFG.dryRun) log(' ⚠ dryRun 模式：只找面单，不真打印');
  log('════════════════════════════════════');
  await refreshIndex();
  const s = stats();
  log('索引完成:', s.files + ' 个 PDF /', s.pages + ' 页面单');
  setInterval(refreshIndex, 30000); // 每 30 秒检查文件夹新面单
});

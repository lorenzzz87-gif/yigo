@echo off
chcp 65001 >nul
title SUVOO 面单打印助手
cd /d "%~dp0"
echo 正在启动 SUVOO 面单打印助手...
node agent.js
pause
